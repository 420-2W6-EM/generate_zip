﻿
namespace ExempleLINQ.ViewModels
{
    public class ResultatDemoProjection3ViewModel
    {
        public int JeuId { get; set; }
        public string NomJeu { get; set; }
        public string NomConsole { get; set; }
    }
}
