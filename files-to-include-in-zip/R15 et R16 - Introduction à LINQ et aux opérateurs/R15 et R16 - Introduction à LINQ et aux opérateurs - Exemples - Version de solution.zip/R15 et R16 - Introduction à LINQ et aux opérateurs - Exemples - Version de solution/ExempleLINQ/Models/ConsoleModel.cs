﻿
using System;
using System.Collections.Generic;

namespace ExempleLINQ.Models
{
    public class ConsoleModel
    {
        public int ConsoleId { get; set; }
        public List<JeuModel> Jeux { get; set; }
        public int CompagnieID { get; set; }
        public CompagnieModel Compagnie { get; set; }
        public string NomConsole { get; set; }

        public ConsoleModel()
        {
            Jeux = new List<JeuModel>();
        }
    }
}
