﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ExempleLINQ.Extensions
{
    public static class MesMethodesExtensions
    {
        public static IEnumerable<T> FilterSelon<T>(this IEnumerable<T> donneesOrigine, Func<T, bool> condition)
        {
            var donnees = donneesOrigine.ToList(); //Créé une copie de la liste
            for (var i = donnees.Count() - 1; i >= 0; i--)
            {
                var element = donnees[i];
                if (condition.Invoke(element))
                {
                    //Rien faire
                }
                else
                {
                    donnees.RemoveAt(i);
                }
            }
            return donnees;
        }
    }
}
