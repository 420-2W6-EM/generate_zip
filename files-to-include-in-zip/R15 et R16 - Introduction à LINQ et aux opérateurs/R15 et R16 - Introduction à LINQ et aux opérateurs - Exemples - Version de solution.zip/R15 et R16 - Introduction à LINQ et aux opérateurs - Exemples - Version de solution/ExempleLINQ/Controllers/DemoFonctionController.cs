﻿using System.Linq;
using System.Collections.Generic;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;
using System;

namespace ExempleLINQ.Controllers
{
    public class DemoFonctionController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoFonctionController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoTypeFunc()
        {
            //Obtenir tous les jeux dont le rating est supérieur ou égale à 8.
            var listeJeux = _baseDonnees.Jeux;

            var donnees = listeJeux.ToList(); //Version #1 : Avec un algorithome
            for (var i = donnees.Count() - 1; i >= 0; i--)
            {
                var jeu = donnees[i];
                if (jeu.Rating >= 8)
                {
                    //Rien faire
                }
                else
                {
                    donnees.RemoveAt(i);
                }
            }

            //var donnees = FilterSelon(listeJeux, EstRatingSuperieurOuEgaleA8); //Version #2 : Passer le nom d'une fonction
            /*var donnees = FilterSelon(listeJeux, (JeuModel jeu) => //Version #3 : Passer une fonction anonyme (version longue)
            {
                return jeu.Rating >= 8;
            });*/
            //var donnees = FilterSelon(listeJeux, jeu => jeu.Rating >= 8); //Version #4 : Passer une fonction anonyme (version simplifiée)
            //var donnees = listeJeux.FilterSelon(jeu => jeu.Rating >= 8); //Version #5 : Méthode d'extension custom + fonction anonyme
            //var donnees = listeJeux.Where(EstRatingSuperieurOuEgaleA8); //Version #6 :Méthode d'extension de LINQ + fonction anonyme


            return View("jeu/lister", donnees);
        }

        private IEnumerable<JeuModel> FilterSelon(IEnumerable<JeuModel> donneesOrigine, Func<JeuModel, bool> fonctionParam)
        {
            var donnees = donneesOrigine.ToList();
            for (var i = donnees.Count() - 1; i >= 0; i--)
            {
                var jeu = donnees[i];
                if (fonctionParam.Invoke(jeu))
                {
                    donnees.RemoveAt(i);
                }
            }
            return donnees;
        }

        private bool EstRatingSuperieurOuEgaleA8(JeuModel jeu)
        {
            return jeu.Rating >= 8;
        }

    }
}
