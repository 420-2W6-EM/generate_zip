﻿using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoAgregationController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoAgregationController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoAverage1()
        {
            //Obtenir la moyenne des prix des jeux
            var donnees = _baseDonnees.Jeux.Average(j => j.PrixActuel);
            return Content(donnees.ToString());
        }
        public IActionResult DemoAverage2()
        {
            //Obtenir la moyenne des prix des jeux de la compagnie Nintendo
            var donnees = _baseDonnees.Jeux.Where(j => j.Console.Compagnie.NomCompagnie == "Nintendo")
                                           .Average(j => j.PrixActuel);

            return Content(donnees.ToString());
        }

        public IActionResult DemoSum1()
        {
            //Le nombre de millions d'exemplaires vendus de la compagnie "Sony"
            var donnees = _baseDonnees.Jeux.Where(j => j.Console.Compagnie.NomCompagnie == "Sony")
                                                    .Sum(j => j.MillionsExemplairesVendus);

            return Content(donnees.ToString());
        }

        public IActionResult DemoAll1()
        {
            //Est-ce que tous les jeux de la console "Switch" sont en bas de 70$
            bool resultat = _baseDonnees.Jeux.Where(j => j.Console.NomConsole == "Switch")
                                             .All(j => j.PrixActuel < 70);

            return resultat ? Content("Oui!") : Content("Non!");
        }

        public IActionResult DemoAny1()
        {
            //Est-ce qu'au moins un jeu de la console PS4 est en bas de 10$
            bool resultat = _baseDonnees.Jeux.Where(j => j.Console.NomConsole == "PlayStation 4")
                                             .Any(j => j.PrixActuel < 10);

            return resultat ? Content("Oui!") : Content("Non!");
        }

    }
}