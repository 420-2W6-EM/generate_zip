﻿using System.Linq;
using ExempleLINQ.Models;
using ExempleLINQ.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoProjectionController : Controller
    {
        private BaseDonnees _baseDonnees;

        public DemoProjectionController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoProjection1()
        {
            //Obtenir tous les jeux (avec toutes ces propriétés) qui ont un rating >= à 5
            var donnees = _baseDonnees.Jeux
                                      .Where(j => j.Rating >= 5)
                                      .Select(x => x);

            return View("Jeu/Lister", donnees);
        }

        public IActionResult DemoProjection2()
        {
            //Obtenir tous les jeux qui ont un rating >= à 5.
            //On souhaite uniquement obtenir l'id du jeu, le nom du jeu et le nom de la console (RIEN D'AUTRE)
            var donnees = _baseDonnees.Jeux
                                      .Where(j => j.Rating >= 5)
                                      .Select(j => new {
                                          JeuId = j.JeuId,
                                          NomJeu = j.NomJeu,
                                          NomConsole = j.Console.NomConsole
                                      });

            return View("DemoProjection3", donnees); //Type anonyme :( ... ça ne marche pas... une vue doit avec des données typées!
        }


        public IActionResult DemoProjection3()
        {
            //Obtenir tous les jeux qui ont un rating >= à 5.
            //On souhaite uniquement obtenir l'id du jeu, le nom du jeu et le nom de la console (RIEN D'AUTRE)
            var donnees = _baseDonnees.Jeux
                                      .Where(j => j.Rating >= 5)
                                      .Select(j => new ResultatDemoProjection3ViewModel
                                      {
                                          JeuId = j.JeuId,
                                          NomJeu = j.NomJeu,
                                          NomConsole = j.Console.NomConsole
                                      });

            return View("DemoProjection3", donnees);  //Typé correctement :) joie et bonheur
        }
    }
}