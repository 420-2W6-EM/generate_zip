﻿using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoElementController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoElementController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoFirst()
        {
            ViewBag.DescriptionRequête = "Obtenir le jeu de \"Zelda\" le plus récent.";
            var donnees = _baseDonnees.Jeux
                                      .Where(j => j.NomJeu.Contains("Zelda"))
                                      .OrderByDescending(j => j.DateParution)
                                      .First();
            return View("Jeu/Afficher", donnees);
        }

        public IActionResult DemoLast()
        {
            ViewBag.DescriptionRequête = "Obtenir le jeu de \"Zelda\" le moins récent.";
            var donnees = _baseDonnees.Jeux
                                      .Where(j => j.NomJeu.Contains("Zelda"))
                                      .OrderByDescending(j => j.DateParution)
                                      .Last();
            return View("Jeu/Afficher", donnees);
        }

        public IActionResult DemoSingle()
        {
            ViewBag.DescriptionRequête = "Obtenir le jeu de \"Zelda Breath of the Wild\".";
            var donnees = _baseDonnees.Jeux
                                      .Where(j => j.NomJeu.Contains("The Legend of Zelda: Breath of the Wild") && j.Console.NomConsole == "Nintendo Switch")
                                      .Single(); //Problème! Existe sur deux consoles! (retirer le && j.Console.NomConsole == "Nintendo Switch")
            return View("Jeu/Afficher", donnees);
        }

    }
}