﻿using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoTriController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoTriController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoTri1()
        {
            ViewBag.DescriptionRequête = "Obtenir tous les jeux triés par la date de parution.";
            var donnees = _baseDonnees.Jeux.OrderBy(j => j.DateParution);
            return View("Jeu/Lister", donnees);
        }

        public IActionResult DemoTri2()
        {
            ViewBag.DescriptionRequête = "Obtenir tous les jeux de la compagnie \"Nintendo\" triés par date de parution.";
            var donnees = _baseDonnees.Jeux.Where(j => j.Console.Compagnie.NomCompagnie == "Nintendo")
                                           .OrderBy(j => j.DateParution);
            return View("Jeu/Lister", donnees);
        }

        public IActionResult DemoTri3()
        {
            ViewBag.DescriptionRequête = "Obtenir tous les jeux de la compagnie \"Nintendo\" triés par nom de console et par date de parution descendant.";
            var donnees = _baseDonnees.Jeux.Where(j => j.Console.Compagnie.NomCompagnie == "Nintendo")
                                           .OrderBy(j => j.Console.NomConsole)
                                           .ThenByDescending(j => j.DateParution);
            return View("Jeu/Lister", donnees);
        }

    }
}