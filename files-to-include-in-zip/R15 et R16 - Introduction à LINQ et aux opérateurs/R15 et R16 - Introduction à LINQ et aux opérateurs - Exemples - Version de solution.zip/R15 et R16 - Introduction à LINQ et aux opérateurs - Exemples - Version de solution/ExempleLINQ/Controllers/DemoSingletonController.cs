﻿using System;
using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers
{
    public class DemoSingletonController : Controller
    {

        private Guid _idControleur { get; set; }
        private BaseDonnees _baseDonnees { get; set; }

        public DemoSingletonController(BaseDonnees donnees)
        {
            _idControleur = Guid.NewGuid();
            _baseDonnees = donnees;
        }

        /*
        public DemoSingletonController()
        {
            _idControleur = Guid.NewGuid();
            _baseDonnees = new BaseDonnees();
        }
        */

        public IActionResult AjouterUneConsolePuisAfficherNombreDeConsoles()
        {
            _baseDonnees.Consoles.Add(new ConsoleModel() { NomConsole = "PlayStation 5" });
            return Content("Nombre de consoles de jeux vidéo : " + _baseDonnees.Consoles.Count() + ", contrôleur : " + _idControleur + ", base de données : " + _baseDonnees.idInstance);
        }
    }
}
