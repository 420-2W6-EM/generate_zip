﻿using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers
{
    public class DemoFormatSynthaxeController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoFormatSynthaxeController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoFormatMethodeExtension()
        {
            //*** AVEC LA SYNTHAXE DES MÉTHODES D'EXTENSION ***
            ViewBag.DescriptionRequête = "Afficher tous les jeux dont le rating est supérieur ou égale à 8 en ordre croisant de nom.";
            var donnees = _baseDonnees.Jeux.Where(j => j.Rating >= 8)
                                           .OrderBy(j => j.NomJeu);

            return View("Jeu/Lister", donnees);
        }

        public IActionResult DemoFormatCompréhension()
        {
            //*** AVEC LA SYNTHAXE DE COMPRÉHENSION ***
            ViewBag.DescriptionRequête = "Afficher tous les jeux dont le rating est supérieur ou égale à 8 en ordre croisant de nom.";
            var donnees = from j in _baseDonnees.Jeux
                          where j.Rating >= 8
                          orderby j.NomJeu
                          select j;

            return View("Jeu/Lister", donnees);
        }

    }
}