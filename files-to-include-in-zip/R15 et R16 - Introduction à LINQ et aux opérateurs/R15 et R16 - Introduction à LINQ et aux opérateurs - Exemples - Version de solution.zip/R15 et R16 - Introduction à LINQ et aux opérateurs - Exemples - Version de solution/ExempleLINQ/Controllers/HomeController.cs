﻿using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
