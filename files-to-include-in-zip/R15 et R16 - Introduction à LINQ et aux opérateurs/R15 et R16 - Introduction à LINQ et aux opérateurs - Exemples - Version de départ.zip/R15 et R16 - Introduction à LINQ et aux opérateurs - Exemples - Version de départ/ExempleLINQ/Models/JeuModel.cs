﻿using System;

namespace ExempleLINQ.Models
{
    public class JeuModel
    {
        public int JeuId { get; set; }
        public int ConsoleId { get; set; }
        public ConsoleModel Console { get; set; }
        public string NomJeu { get; set; }
        public decimal MillionsExemplairesVendus { get; set; }
        public decimal PrixActuel { get; set; }
        public decimal Rating { get; set; }
        public string Developpeur { get; set; }
        public string Editeur { get; set; }
        public DateTime DateParution { get; set; }
        public int QuantitéRestante { get; set; }

    }
}
