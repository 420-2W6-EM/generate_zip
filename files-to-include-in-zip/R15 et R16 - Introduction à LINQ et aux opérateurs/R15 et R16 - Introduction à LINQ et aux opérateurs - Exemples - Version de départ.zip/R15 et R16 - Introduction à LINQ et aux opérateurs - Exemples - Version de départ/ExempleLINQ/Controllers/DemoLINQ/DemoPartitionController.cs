﻿using System;
using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoPartitionController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoPartitionController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult DemoTake1()
        {
            ViewBag.DescriptionRequête = "Obtenir les jeux parru dans les 5 dernières années triés par nom. Limiter le résultat aux 5 premiers.";

            return View();
        }

        public IActionResult DemoSkip1()
        {
            ViewBag.DescriptionRequête = "Obtenir les jeux parru dans les 6 dernières années triés par nom. Ne pas considérer les 5 premiers résultats (ne pas les retourner).";

            return View();
        }

        public IActionResult DemoSkip2()
        {
            ViewBag.DescriptionRequête = "Obtenir les jeux parru dans les 8 dernières années triés par nom. Cependant, afficher uniquement les résultats pour la page 3 (il y a 5 éléments par page).";

            var numeroPage = 3;
            var nombreElementsParPage = 5;


            return View();
        }

    }
}