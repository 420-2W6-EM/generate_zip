﻿using System.Collections.Generic;
using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoRestrictionController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoRestrictionController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoWhere1()
        {
            ViewBag.DescriptionRequête = "Obtenir tous les jeux dont la quantité restante est supérieur ou égale à 50";

            return View();
        }

        public IActionResult DemoWhere2()
        {
            ViewBag.DescriptionRequête = "Obtenir toutes les consoles de la compagnie \"Nintendo\" dont le nombre de jeu est supérieur à 22";

            return View();
        }

        public IActionResult DemoWhere3()
        {
            ViewBag.DescriptionRequête = "Restrictions personnalisées par composition";

            string nomCompagnie = "";
            int? nombreJeuxMinimum = null;

            IEnumerable<ConsoleModel> donnees = _baseDonnees.Consoles;

            //Si un nom de compagnie est spécifié, limiter les consoles à celles de cette compagnie


            //Si un nombre de jeu minimum est spécifié, limiter les consoles à celles possèdantes le nombre de jeu minimum souhaité


            return View();
        }
    }
}