﻿using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoElementController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoElementController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoFirst()
        {
            ViewBag.DescriptionRequête = "Obtenir le jeu de \"Zelda\" le plus récent.";

            return View();
        }

        public IActionResult DemoLast()
        {
            ViewBag.DescriptionRequête = "Obtenir le jeu de \"Zelda\" le moins récent.";

            return View();


        }

        public IActionResult DemoSingle()
        {
            ViewBag.DescriptionRequête = "Obtenir le jeu de \"Zelda Breath of the Wild\".";

            return View();
        }

    }
}