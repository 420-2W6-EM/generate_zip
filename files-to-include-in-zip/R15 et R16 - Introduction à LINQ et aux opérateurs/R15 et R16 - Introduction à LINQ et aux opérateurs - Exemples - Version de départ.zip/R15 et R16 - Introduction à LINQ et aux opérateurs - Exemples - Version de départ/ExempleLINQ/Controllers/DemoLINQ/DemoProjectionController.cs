﻿using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoProjectionController : Controller
    {
        private BaseDonnees _baseDonnees;

        public DemoProjectionController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoProjection1()
        {
            //Obtenir tous les jeux (avec toutes ces propriétés) qui ont un rating >= à 5

            return View();
        }

        public IActionResult DemoProjection2()
        {
            //Obtenir tous les jeux qui ont un rating >= à 5.
            //On souhaite uniquement obtenir l'id du jeu, le nom du jeu et le nom de la console (RIEN D'AUTRE)

            return View();
        }


        public IActionResult DemoProjection3()
        {
            //Obtenir tous les jeux qui ont un rating >= à 5.
            //On souhaite uniquement obtenir l'id du jeu, le nom du jeu et le nom de la console (RIEN D'AUTRE)

            return View();
        }
    }
}