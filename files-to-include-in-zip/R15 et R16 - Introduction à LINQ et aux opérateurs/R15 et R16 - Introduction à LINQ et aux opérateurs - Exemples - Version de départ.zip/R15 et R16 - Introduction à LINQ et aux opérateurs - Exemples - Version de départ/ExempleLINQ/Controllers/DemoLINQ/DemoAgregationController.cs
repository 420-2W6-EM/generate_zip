﻿using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers.DemoLINQ
{
    public class DemoAgregationController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoAgregationController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoAverage1()
        {
            //Obtenir la moyenne des prix des jeux

            return Content("");
        }
        public IActionResult DemoAverage2()
        {
            //Obtenir la moyenne des prix des jeux de la compagnie Nintendo

            return Content("");
        }

        public IActionResult DemoSum1()
        {
            //Le nombre de millions d'exemplaires vendus de la compagnie "Sony"

            return Content("");
        }

        public IActionResult DemoAll1()
        {
            //Est-ce que tous les jeux de la console "Switch" sont en bas de 70$

            return Content("");
        }

        public IActionResult DemoAny1()
        {
            //Est-ce qu'au moins un jeu de la console "PS4" est en bas de 10$

            return Content("");
        }

    }
}