﻿using System.Linq;
using System.Collections.Generic;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;
using System;

namespace ExempleLINQ.Controllers
{
    public class DemoFonctionController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoFonctionController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoTypeFunc()
        {
            //Obtenir tous les jeux dont le rating est supérieur ou égale à 8.
            var listeJeux = _baseDonnees.Jeux;

            var donnees = listeJeux.ToList(); //Version #1 : Avec un algorithome
            for (var i = donnees.Count() - 1; i >= 0; i--)
            {
                var jeu = donnees[i];
                if (jeu.Rating >= 8)
                {
                    //Rien faire
                }
                else
                {
                    donnees.RemoveAt(i);
                }
            }

            return View("jeu/lister", donnees);
        }

        private bool EstRatingSuperieurOuEgaleA8(JeuModel jeu)
        {
            return jeu.Rating >= 8;
        }

    }
}