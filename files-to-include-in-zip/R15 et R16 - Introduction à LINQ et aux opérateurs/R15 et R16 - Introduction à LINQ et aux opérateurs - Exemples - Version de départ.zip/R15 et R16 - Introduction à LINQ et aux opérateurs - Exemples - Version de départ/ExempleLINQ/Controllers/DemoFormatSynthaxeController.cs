﻿using System.Linq;
using ExempleLINQ.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExempleLINQ.Controllers
{
    public class DemoFormatSynthaxeController : Controller
    {

        private BaseDonnees _baseDonnees;

        public DemoFormatSynthaxeController(BaseDonnees baseDonnees)
        {
            _baseDonnees = baseDonnees;
        }

        public IActionResult DemoFormatMethodeExtension()
        {
            //*** AVEC LA SYNTHAXE DES MÉTHODES D'EXTENSION ***
            ViewBag.DescriptionRequête = "Afficher tous les jeux dont le rating est supérieur ou égale à 8 en ordre croisant de nom.";

            return View();
        }

        public IActionResult DemoFormatCompréhension()
        {
            //*** AVEC LA SYNTHAXE DE COMPRÉHENSION ***
            ViewBag.DescriptionRequête = "Afficher tous les jeux dont le rating est supérieur ou égale à 8 en ordre croisant de nom.";

            return View();
        }

    }
}