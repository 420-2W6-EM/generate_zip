﻿using System.Collections.Generic;
using System.Linq;

namespace ExercicePokemon.Models
{
    public class BaseDeDonnees
    {

    }
}
