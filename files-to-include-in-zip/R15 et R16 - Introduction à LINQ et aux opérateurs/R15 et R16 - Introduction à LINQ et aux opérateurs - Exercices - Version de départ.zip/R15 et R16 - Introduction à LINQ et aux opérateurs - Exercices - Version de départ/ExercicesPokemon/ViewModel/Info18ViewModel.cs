﻿namespace ExercicePokemon.ViewModels
{
    public class Info18ViewModel
    {
        /* À COMPLÉTER (3 DOUBLES)*/
    }
}
