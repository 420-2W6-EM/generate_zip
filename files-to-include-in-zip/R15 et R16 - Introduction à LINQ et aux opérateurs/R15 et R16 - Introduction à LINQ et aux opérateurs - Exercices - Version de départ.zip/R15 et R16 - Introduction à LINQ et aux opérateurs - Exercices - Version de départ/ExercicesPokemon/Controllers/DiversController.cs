﻿using System.Linq;
using ExercicePokemon.Models;
using ExercicePokemon.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ExercicePokemon.Controllers
{
    public class DiversController : Controller
    {
        /* IMPORTANT RETIRER CES COMMENTAIRES!
        private BaseDeDonnees BD { get; set; }

        public DiversController(BaseDeDonnees baseDeresultat)
        {
            BD = baseDeresultat;
        }

        public IActionResult Menu()
        {
            return View();
        }
         */

        public IActionResult Info1()
        {
            ViewData["description"] = "Afficher tous les pokémons";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }

        public IActionResult Info2()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire l'eau";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }

        public IActionResult Info3()
        {
            ViewData["description"] = "Afficher les 5 premiers pokémons ayant comme type primaire l'eau";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }

        public IActionResult Info4()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire l'électricité trié par puissance d'attaque";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }

        public IActionResult Info5()
        {
            ViewData["description"] = "Afficher les pokémons ayant la syllable \"chu\" dans leur nom";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }
        public IActionResult Info6()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu et qui ont une puissant d'attaque supérieur à 60";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }
        public IActionResult Info7()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu, l'eau ou l'herbe";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }
        public IActionResult Info8()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu, l'eau ou l'herbe trié par type primaire";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }
        public IActionResult Info9()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu, l'eau ou l'herbe trié par type primaire puis par leur nom";

            // À COMPLÉTER

            return View("AfficherListePokemons"); //PASSER LE MODÈLE
        }
        public IActionResult Info10()
        {
            ViewData["description"] = "Afficher le pokémon ayant le numéro 55";

            // À COMPLÉTER

            return View("AfficherUnPokemon"); //PASSER LE MODÈLE
        }
        public IActionResult Info11()
        {
            ViewData["description"] = "Afficher le pokémon le plus lent";

            // À COMPLÉTER

            return View("AfficherUnPokemon"); //PASSER LE MODÈLE
        }
        public IActionResult Info12()
        {
            ViewData["description"] = "Afficher le pokémon le plus rapide";

            // À COMPLÉTER

            return View("AfficherUnPokemon"); //PASSER LE MODÈLE
        }
        public IActionResult Info13()
        {
            ViewData["description"] = "Afficher le 3ème pokémon le plus rapide";

            // À COMPLÉTER

            return View("AfficherUnPokemon"); //PASSER LE MODÈLE
        }
        public IActionResult Info14()
        {
            ViewData["description"] = "Afficher le dernier pokémon de type eau";

            // À COMPLÉTER

            return View("AfficherUnPokemon"); //PASSER LE MODÈLE
        }
        public IActionResult Info15()
        {
            ViewData["description"] = "Combien de pokémons ont une attaque supérieur à 40?";

            // À COMPLÉTER

            return View("AfficherUnEntier"); //PASSER LE MODÈLE
        }
        public IActionResult Info16()
        {
            ViewData["description"] = "Quelle est la moyenne d'attaque des pokémons?";

            // À COMPLÉTER

            return View("AfficherUnDouble"); //PASSER LE MODÈLE
        }
        public IActionResult Info17()
        {
            ViewData["description"] = "Quelle est la moyenne d'attaque des pokémons de type primaire feu?";

            // À COMPLÉTER

            return View("AfficherUnDouble"); //PASSER LE MODÈLE
        }
        public IActionResult Info18()
        {
            ViewData["description"] = "Afficher les informations sur la moyenne des attaques de pokémons de type feu, d'eau et d'herbe séparément";

            // À COMPLÉTER

            //Puisque la structure de données à afficher est particulière à cette vue (3 doubles) vous devez créer un ViewModel (nommé Info18ViewModel) comme modèle pour cette vue.
            //Indice : le contrôleur devra faire 3 requêtes LINQ différentes sur le modèle afin de pouvoir remplir les propriétés de ce ViewModel

            return View("AfficherInfo18");
        }
    }
}