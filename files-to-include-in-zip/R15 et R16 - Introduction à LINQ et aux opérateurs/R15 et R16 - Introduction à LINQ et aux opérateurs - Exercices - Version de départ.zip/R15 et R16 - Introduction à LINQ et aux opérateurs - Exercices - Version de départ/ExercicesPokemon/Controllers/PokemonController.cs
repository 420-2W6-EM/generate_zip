﻿using ExercicePokemon.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace ExercicePokemon.Controllers
{
    public class PokemonController : Controller
    {
        private BaseDeDonnees BD { get; set; }

        public PokemonController()
        {
            BD = new BaseDeDonnees();
        }

        /*
        public IActionResult Lister()
        {
            return View(BD.Pokemons.ToList());
        }

        public IActionResult Consulter(int id)
        {
            var pokemonRecherché = BD.Pokemons.Where(p => p.Id == id).Single();
            return View(pokemonRecherché);
        }
        */
    }
}