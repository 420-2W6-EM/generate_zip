﻿using System.Linq;
using ExercicePokemon.Models;
using ExercicePokemon.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ExercicePokemon.Controllers
{
    public class DiversController : Controller
    {
        private BaseDeDonnees _baseDeDonnees { get; set; }

        public DiversController(BaseDeDonnees baseDeresultat)
        {
            _baseDeDonnees = baseDeresultat;
        }

        public IActionResult Menu()
        {
            return View();
        }

        public IActionResult Info1()
        {
            ViewData["description"] = "Afficher tous les pokémons";
            var resultat = _baseDeDonnees.Pokemons.ToList();
            return View("AfficherListePokemons", resultat);
        }

        public IActionResult Info2()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire l'eau";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Water").ToList();
            return View("AfficherListePokemons", resultat);
        }

        public IActionResult Info3()
        {
            ViewData["description"] = "Afficher les 5 premiers pokémons ayant comme type primaire l'eau";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Water").Take(5).ToList();
            return View("AfficherListePokemons", resultat);
        }

        public IActionResult Info4()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire l'électricité trié par puissance d'attaque";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Electric").OrderBy(p => p.Attaque).ToList();
            return View("AfficherListePokemons", resultat);
        }

        public IActionResult Info5()
        {
            ViewData["description"] = "Afficher les pokémons ayant la syllable \"chu\" dans leur nom";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.Nom.Contains("chu")).ToList();
            return View("AfficherListePokemons", resultat);
        }
        public IActionResult Info6()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu et qui ont une puissant d'attaque supérieur à 60";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Fire" && p.Attaque > 60).ToList();
            return View("AfficherListePokemons", resultat);
        }
        public IActionResult Info7()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu, l'eau ou l'herbe trié par type primaire puis par leur nom";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Fire" || p.TypePrimaire == "Water" || p.TypePrimaire == "Grass").ToList();
            return View("AfficherListePokemons", resultat);
        }
        public IActionResult Info8()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu, l'eau ou l'herbe trié par type primaire";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Fire" || p.TypePrimaire == "Water" || p.TypePrimaire == "Grass").OrderBy(p => p.TypePrimaire).ToList();
            return View("AfficherListePokemons", resultat);
        }
        public IActionResult Info9()
        {
            ViewData["description"] = "Afficher les pokémons ayant comme type primaire le feu, l'eau ou l'herbe trié par type primaire puis par leur nom";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Fire" || p.TypePrimaire == "Water" || p.TypePrimaire == "Grass").OrderBy(p => p.TypePrimaire).ThenBy(p => p.Nom).ToList();
            return View("AfficherListePokemons", resultat);
        }
        public IActionResult Info10()
        {
            ViewData["description"] = "Afficher le pokémon ayant le numéro 55";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.Id == 55).Single();
            return View("AfficherUnPokemon", resultat);
        }
        public IActionResult Info11()
        {
            ViewData["description"] = "Afficher le pokémon le plus lent";
            var resultat = _baseDeDonnees.Pokemons.OrderBy(p => p.Vitesse).First();
            return View("AfficherUnPokemon", resultat);
        }
        public IActionResult Info12()
        {
            ViewData["description"] = "Afficher le pokémon le plus rapide";
            var resultat = _baseDeDonnees.Pokemons.OrderByDescending(p => p.Vitesse).First();
            return View("AfficherUnPokemon", resultat);
        }
        public IActionResult Info13()
        {
            ViewData["description"] = "Afficher le 3ème pokémon le plus rapide";
            var resultat = _baseDeDonnees.Pokemons.OrderByDescending(p => p.Vitesse).Skip(2).First();
            return View("AfficherUnPokemon", resultat);
        }
        public IActionResult Info14()
        {
            ViewData["description"] = "Afficher le dernier pokémon de type eau";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Water").OrderByDescending(p => p.Id).First();
            return View("AfficherUnPokemon", resultat);
        }
        public IActionResult Info15()
        {
            ViewData["description"] = "Combien de pokémons ont une attaque supérieur à 40?";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.Attaque > 40).Count();
            return View("AfficherUnEntier", resultat);
        }
        public IActionResult Info16()
        {
            ViewData["description"] = "Quelle est la moyenne d'attaque des pokémons?";
            var resultat = _baseDeDonnees.Pokemons.Average(p => p.Attaque);
            return View("AfficherUnDouble", resultat);
        }
        public IActionResult Info17()
        {
            ViewData["description"] = "Quelle est la moyenne d'attaque des pokémons de type primaire feu?";
            var resultat = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Fire").Average(p => p.Attaque);
            return View("AfficherUnDouble", resultat);
        }
        public IActionResult Info18()
        {
            ViewData["description"] = "Afficher les informations sur la moyenne des attaques de pokémons de type feu, d'eau et d'herbe séparément";
            //Puisque la structure de données à afficher est particulière à cette vue (3 doubles) vous devez créer un ViewModel comme modèle pour cette vue.
            //Indice : le contrôleur devra faire 3 requêtes LINQ différentes sur le modèle afin de pouvoir remplir les propriétés de ce ViewModel
            var resultat = new Info18ViewModel();
            resultat.MoyenneEau = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Water").Average(p => p.Attaque);
            resultat.MoyenneFeu = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Fire").Average(p => p.Attaque);
            resultat.MoyenneHerbe = _baseDeDonnees.Pokemons.Where(p => p.TypePrimaire == "Grass").Average(p => p.Attaque);
            return View("AfficherInfo18", resultat);
        }
    }
}