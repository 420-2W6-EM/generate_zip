﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ForetBoreale.Models
{
    public class Catalogues
    {
        public List<Arbre> ObtenirListArbres()
        {
            var Arbres = new List<Arbre>();
            Arbres.Add(new Arbre() { Id = 1, Nom = "Pin", Description = "« Pin » est la désignation générique des conifères appartenant au genre Pinus, de la famille des Pinacées. À Haïti ils sont appelés « bois chandelle » ou « bois pin »", EspeceResineuse = true });
            Arbres.Add(new Arbre() { Id = 2, Nom = "Épinettes", Description = "Picea est un genre de conifères qui regroupe une cinquantaine d'espèces répandues dans l’hémisphère nord, en Europe, en Asie et en Amérique.", EspeceResineuse = true });
            Arbres.Add(new Arbre() { Id = 3, Nom = "Mélèzes", Description = "Mélèze est un nom vernaculaire ambigu en français. On appelle « mélèze » divers arbres des régions tempérées de l'hémisphère nord. Ils font partie de la famille des Pinaceae. Ils atteignent facilement 20-45 mètres de haut.", EspeceResineuse = true });
            Arbres.Add(new Arbre() { Id = 4, Nom = "Sapins", Description = "Sapin , bien que ce terme ait anciennement un sens plus large et désigne parfois des espèces d'autres genres. Il est originaires des régions tempérées de l'hémisphère nord.", EspeceResineuse = true, });
            Arbres.Add(new Arbre() { Id = 5, Nom = "Thuyas", Description = "Les thuyas (Thuja), appelés aussi cèdres au Canada, sont un genre de conifères de la famille des cupressacées, originaires des régions tempérées de l'hémisphère nord. ", EspeceResineuse = true, });
            Arbres.Add(new Arbre() { Id = 6, Nom = "Peupliers", Description = "Les peupliers sont des arbres du genre Populus de la famille des Salicacées. Le genre Populus englobe 35 espèces des régions tempérées et froides de l'hémisphère nord.", EspeceResineuse = false });
            Arbres.Add(new Arbre() { Id = 7, Nom = "Bouleux", Description = "Les bouleaux font partie de la famille des bétulacées et du genre Betula. La plupart des espèces sont des arbres ; quelques-unes, comme Betula nana, sont des chaméphytes.", EspeceResineuse = false });
            return Arbres;
        }
    }
}
