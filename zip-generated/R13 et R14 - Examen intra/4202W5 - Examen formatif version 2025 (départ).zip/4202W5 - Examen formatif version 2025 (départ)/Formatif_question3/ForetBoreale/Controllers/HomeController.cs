﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ForetBoreale.Models;

namespace ForetBoreale.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var baseDeDonnees = new Catalogues();
            var donnees = baseDeDonnees.ObtenirListArbres();
            return View(donnees);
        }

        public IActionResult Consulter(int id)
        {
            var baseDeDonnees = new Catalogues();
            var donnees = baseDeDonnees.ObtenirListArbres();
            foreach (var element in donnees)
            {
                if (id == element.Id)
                {
                    return View(element);
                }

            }
            return NotFound();
        }
    }
}
