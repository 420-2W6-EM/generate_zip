﻿using ExercicePokemon.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace ExercicePokemon.Controllers
{
    public class PokemonController : Controller
    {
        private BaseDeDonnees _baseDeDonnees { get; set; }

        public PokemonController(BaseDeDonnees baseDeDonnees)
        {
            _baseDeDonnees = baseDeDonnees;
        }

        public IActionResult Lister()
        {
            return View(_baseDeDonnees.Pokemons.ToList());
        }

        public IActionResult Recherche(string terme, string type)
        {
            IEnumerable<Pokemon> pokemonsFiltrés = _baseDeDonnees.Pokemons;

            //ÉTAPE #1 
            //Si le "type" n'a pas la valeur null, appliquer un filtre sur les pokemons afin de conserver uniquement
            //ceux dont le type primaire OU le type secondaire correspond à celui du "type" reçu.


            //ÉTAPE #2 
            //Si le "terme" n'a pas la valeur null, appliquer un filtre sur les pokemons afin de conserver uniquement
            //ceux dont le nom du pokémon contient le "terme" (sans tenir compte de la casse) OU si le numéro
            //du pokémon est identique à la valeur du "terme"

            //ÉTAPE #3 
            //Il n'existe pas de vue "Recherche"!
            //Retourner les données dans la vue permettant d'afficher la liste des pokémons!
            return View("NOM_DE_LA_VUE", pokemonsFiltrés.ToList());
        }

        public IActionResult Consulter(int id)
        {
            var pokemonRecherché = _baseDeDonnees.Pokemons.Where(p => p.Id == id).SingleOrDefault();
            if (pokemonRecherché == null)
            {
                return View("NonTrouvé", "Le numéro de pokémon demandé n'a pas été trouvé!");
            }
            else
            {
                return View(pokemonRecherché);
            }
        }
    }
}