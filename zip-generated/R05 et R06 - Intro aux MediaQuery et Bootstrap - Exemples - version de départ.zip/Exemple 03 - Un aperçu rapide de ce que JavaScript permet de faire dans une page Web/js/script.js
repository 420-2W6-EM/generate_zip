
/**
 * Cette fonction permet d'afficher les informations de Pikachu à l'écran
 */
function afficherPikachu() {
    document.getElementById("nomPokemon").innerText = "Pikachu #025";
    document.getElementById("descriptionPokemon").innerText = "Whenever Pikachu comes across something new, it blasts it with a jolt of electricity. If you come across a blackened berry, it's evidence that this Pokémon mistook the intensity of its charge.";
    document.getElementById("typePokemon").innerText = "Electic";
    document.getElementById("imagePokemon").src = "images/025.png"
    document.body.style.backgroundColor = "rgb(255, 196, 0)";
}

/**
 * Cette fonction permet d'afficher les informations de Blastoise à l'écran
 */
function afficherBlastoise() {
    document.getElementById("nomPokemon").innerText = "Blastoise #009";
    document.getElementById("descriptionPokemon").innerText = "Blastoise has water spouts that protrude from its shell. The water spouts are very accurate. They can shoot bullets of water with enough accuracy to strike empty cans from a distance of over 160 feet.";
    document.getElementById("typePokemon").innerText = "Water";
    document.getElementById("imagePokemon").src = "images/009.png"
    document.body.style.backgroundColor = "rgb(0, 204, 255)";
}

/**
 * Cette fonction permet d'afficher le pokémon dont le numéro est passé en paramètre
 */
function afficherPokemon(numeroPokemon) {
    if(numeroPokemon == 9) {
        afficherBlastoise();
    } else if(numeroPokemon == 25) {
        afficherPikachu();
    } else {
        alert("Le code pour ce pokémon na pas encore été écrit par le développeur");
    }
}

/**
 * Basculer entre l'affichage de pikachu et de blastoire
 */
function basculerEntrePikachuEtBlastoire() {
    var nomPokemon = document.getElementById("nomPokemon").innerText;
    if(nomPokemon == "Blastoise #009") {
        afficherPikachu();
    } else {
        afficherBlastoise();
    }
}

/**
 * Mettre la propriété "block" au menu (par défaut, à cause du CSS s'était à none)
 */
function afficherLeMenu() {
    document.getElementById("menu").style.display = "block";
}

/**
 * Fermer le menu. Dans cette exemple, cela se fait en lui donnant la valeur "none" à la propriété "display".
 */
function fermerLeMenu() {
    document.getElementById("menu").style.display = "none";
}

var compteur = 1;
/**
 * Créer un nouveau élément "img" et le rajouter comme enfant de l'élément ayant le id "ListePokemons"
 */
function afficherLeProchainPokemon() {
    var listePokemon = document.getElementById("ListePokemons");
    var nouveauPokemon = document.createElement('img');
    nouveauPokemon.width = "100";
    nouveauPokemon.height = "100";
    nouveauPokemon.src = "images/petit/" + compteur + ".png";
    listePokemon.appendChild(nouveauPokemon); 
    compteur++;
}
