﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmongUs.Models
{
    public class Crewmate
    {
        public string Color { get; set; } // Couleur, doit être unique

        public bool IsImposter { get; set; } // Imposteur ou non ?

        public int Victories { get; set; } // Nombre de victoires

        public string Strategy { get; set; } // Explications sur sa stratégie préférée

        public string FavoriteMap { get; set; } // Map préférée parmi "Mira HQ", "Polus" et "The Skeld"
    }
}
