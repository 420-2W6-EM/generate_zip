﻿using Ex_Cours9.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ex_cours9.Controllers
{
    public class HomeController : Controller
    {
        private Database DB;
        public HomeController(Database db)
        {
            DB = db;
        }
        public IActionResult Index(int? id)
        {
            Bee bee = DB.Bees.Where(b => b.Id == id).SingleOrDefault();
            if (bee == null)
                return View(null);
            return View(bee);
        }
    }
}
