﻿using AmongUs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmongUs.Controllers
{
    public class CrewmateController : Controller
    {
        private Database DB;
        public CrewmateController(Database db)
        {
            DB = db;
        }
        // GET: CrewmateController
        public ActionResult Index()
        {
            return View(DB.Crewmates.ToList());
        }

        // GET: CrewmateController/Details/5
        public ActionResult Details(string id)
        {
            Crewmate crewmate = DB.Crewmates.Where(c => c.Color == id).Single();
            return View(crewmate);
        }

        // GET: CrewmateController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CrewmateController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Crewmate crewmate)
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError(nameof(crewmate), "Votre nouveau crewmate est invalide.");
                return View();
            }
            if (DB.Crewmates.Any(c => c.Color == crewmate.Color))
            {
                ModelState.AddModelError(nameof(crewmate.Color), "Cette couleur est déjà utilisée.");
                return View();
            }
            try
            {
                DB.Crewmates.Add(crewmate);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CrewmateController/Delete/5
        public ActionResult Delete(string id)
        {
            Crewmate crewmate = DB.Crewmates.Where(c => c.Color == id).Single();
            return View(crewmate);
        }

        // POST: CrewmateController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, Crewmate crewmate)
        {
            try
            {
                Crewmate delete = DB.Crewmates.Where(c => c.Color == id).Single();
                DB.Crewmates.Remove(delete);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
