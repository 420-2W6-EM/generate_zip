﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AmongUs.Models
{
    public class Crewmate
    {
        [Required(ErrorMessage = "Entrez une couleur.")]
        [Display(Name = "Couleur :")]
        public string Color { get; set; } // Couleur, doit être unique

        [Display(Name = "Imposteur")]
        public bool IsImposter { get; set; } // Imposteur ou non ?

        [Required]
        [Range(1, 100, ErrorMessage = "Entre 1 et 100.")]
        [Display(Name = "Nombre de victoires :")]
        public int Victories { get; set; } // Nombre de victoires

        [Required(ErrorMessage = "Décrivez une stratégie.")]
        [MaxLength(200, ErrorMessage = "200 caractères maximum.")]
        [Display(Name = "Stratégie préférée :")]
        public string Strategy { get; set; } // Explications sur sa stratégie préférée

        [Display(Name = "Carte préférée :")]
        public string? FavoriteMap { get; set; } // Map préférée parmi "Mira HQ", "Polus" et "The Skeld"
    }
}
