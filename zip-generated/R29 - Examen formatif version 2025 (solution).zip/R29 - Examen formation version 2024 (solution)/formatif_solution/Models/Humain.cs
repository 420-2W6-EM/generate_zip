﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace formatif.Models
{
    public class Humain
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Description { get; set; }
    }
}
