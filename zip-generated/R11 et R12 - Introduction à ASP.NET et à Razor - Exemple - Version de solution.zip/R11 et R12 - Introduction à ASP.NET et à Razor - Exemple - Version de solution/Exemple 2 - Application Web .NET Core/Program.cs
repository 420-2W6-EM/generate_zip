using Microsoft.AspNetCore.Builder;

var builder = WebApplication.CreateBuilder(args);

//builder.Services.AddMvc();//.AddRazorRuntimeCompilation();
//builder.Services.AddRazorPages().AddRazorRuntimeCompilation(); //Besoin d'inclure la bibliotheque (package NuGet) : Microsoft.AspNetCore.Mvc.Razor.RuntimeCompilation
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();//.AddRazorRuntimeCompilation();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseStaticFiles(new StaticFileOptions
    {
        OnPrepareResponse = context => context.Context.Response.Headers.Add("Cache-Control", "no-cache")
    });
}
else
{
    app.UseStaticFiles();
}


app.UseRouting();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller}/{action}/{id?}",
        defaults: new { controller = "Personne", action = "Lister" });
});

app.MapRazorPages();
app.Run();
