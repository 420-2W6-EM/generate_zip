﻿using Exemple.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exemple.Controllers
{
    public class PersonneController : Controller
    {
        public IActionResult Lister()
        {
            var mesDonnees = ObtenirListePersonnes();
            return View(mesDonnees);
        }

        public IActionResult Consulter(int id)
        {
            Personne personneAConsultée = null;
            var personnes = ObtenirListePersonnes();
            foreach (var personne in personnes)
            {
                if (personne.Id == id)
                {
                    personneAConsultée = personne;
                }
            }
            return View(personneAConsultée);
        }

        private List<Personne> ObtenirListePersonnes()
        {
            var personnes = new List<Personne>() {
        new Personne() { Id=1, Nom = "Robert Lapointe", Nas = "276-187-261", Age = 17, Image="/images/personne1.jpg", AÉtéFraudé = false },
        new Personne() { Id=2, Nom = "Denis Verreau", Nas = "527-189-354", Age = 20, Image="/images/personne2.jpg", AÉtéFraudé = true  },
        new Personne() { Id=3, Nom = "Louise Tremblay", Nas = "782-356-273", Age = 28, Image="/images/personne3.jpg", AÉtéFraudé = false }
    };
            return personnes;
        }
    }
}
