﻿using System.Linq;
using System.Collections.Generic;

namespace Exemple.Models
{
    public class BaseDonnees
    {
        public List<PersonneModel> Personnes;

        public List<ForfaitModel> Forfaits;

        public BaseDonnees()
        {

            Forfaits = new List<ForfaitModel>()
            {
                new ForfaitModel() { Id = 6, Nom = "Bronze", Prix = 0, Description = "Forfait sans service"},
                new ForfaitModel() { Id = 7, Nom = "Argent", Prix = 5, Description = "Forfait avec un service très ordinaire"},
                new ForfaitModel() { Id = 8, Nom = "Or", Prix = 10, Description = "Forfait avec un bon service"},
                new ForfaitModel() { Id = 9, Nom = "Platine", Prix = 20, Description = "Forfait avec une tonne de service"}
            };

            Personnes = new List<PersonneModel>()
            {
                new PersonneModel() { Id=1, Nom = "Robert Lapointe", Nas = "276-187-261", Age = 17, Image="/images/personne1.jpg", AÉtéFraudé = false, ForfaitId = 6, Forfait = Forfaits.Single(f => f.Id == 6) },
                new PersonneModel() { Id=2, Nom = "Denis Verreau", Nas = "527-189-354", Age = 20, Image="/images/personne2.jpg", AÉtéFraudé = true, ForfaitId = 7, Forfait = Forfaits.Single(f => f.Id == 7)  },
                new PersonneModel() { Id=3, Nom = "Louise Tremblay", Nas = "782-356-273", Age = 28, Image="/images/personne3.jpg", AÉtéFraudé = false, ForfaitId = 8, Forfait = Forfaits.Single(f => f.Id == 8) }
            };

        }
    }
}