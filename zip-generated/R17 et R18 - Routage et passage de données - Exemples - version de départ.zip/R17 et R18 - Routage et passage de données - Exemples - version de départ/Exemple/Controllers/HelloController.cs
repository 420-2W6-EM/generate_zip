﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Exemple.Controllers
{
    public class HelloController : Controller
    {
        public IActionResult Action1()
        {
            return Content("Hello World!");
        }
    }
}