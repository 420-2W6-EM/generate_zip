﻿using Microsoft.AspNetCore.Mvc;

namespace Exemple.Controllers
{
    public class RoutageExemple1Controller : Controller
    {

        public IActionResult Index()
        {
            return Content("Exemple 1 - Index");
        }

        public IActionResult ObtenirClientParId(int clientId)
        {
            return Content("Exemple 2 - ObtenirClientParId");
        }

        public IActionResult ObtenirClientParNom(string clientName)
        {
            return Content("Exemple 3 - ObtenirClientParNom");
        }

        public IActionResult Edit(int clientId)
        {
            return Content("Exemple 4 - Edit");
        }

    }
}