﻿using Microsoft.AspNetCore.Mvc;

namespace Exemple.Controllers
{

    public class RoutageExemple2Controller : Controller
    {

        public IActionResult Index()
        {
            return Content("Exemple 5 - Index");
        }

        public IActionResult Details(int animalId)
        {
            return Content("Exemple 6 - Details");
        }

        public IActionResult Edit(int clientId)
        {
            return Content("Exemple 7 - Edit");
        }

    }
}