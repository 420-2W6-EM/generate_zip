﻿namespace Exemple.Models
{
    public class PersonneModel
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Nas { get; set; }
        public string Image { get; set; }
        public int Age { get; set; }
        public bool AÉtéFraudé { get; set; }
        public int ForfaitId { get; set; }
        public ForfaitModel Forfait { get; set; }
    }
}
