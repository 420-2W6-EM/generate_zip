﻿using System.Collections.Generic;

namespace Exemple.Models
{
    public class ForfaitModel
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public decimal Prix { get; set; }
        public string Nom { get; set; }
        public List<PersonneModel> Personnes { get; set; }

        public ForfaitModel()
        {
            Personnes = new List<PersonneModel>();
        }

    }
}
