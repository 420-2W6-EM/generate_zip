﻿using Exemple.Models;
using System.Collections.Generic;

namespace Exemple.ViewModels
{
    public class AffichageExempleViewModel
    {
        public string NomUtilisateur { get; set; }
        public PersonneModel UnePersonne { get; set; }
        public List<ForfaitModel> Forfaits { get; set; }
    }
}
