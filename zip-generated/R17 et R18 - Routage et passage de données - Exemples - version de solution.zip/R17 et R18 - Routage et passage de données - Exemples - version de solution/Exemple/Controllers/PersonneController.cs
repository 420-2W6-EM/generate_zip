﻿using Exemple.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Exemple.Controllers
{
    public class PersonneController : Controller
    {
        private BaseDonnees _baseDonnees { get; set; }

        public PersonneController(BaseDonnees pDonnees)
        {
            _baseDonnees = pDonnees;
        }

        [Route("personne")]
        [Route("personne/lister")]
        public IActionResult Lister()
        {
            var donnees = _baseDonnees.Personnes.ToList();
            return View(donnees);
        }

        [Route("personne/consulter/{id:int}")]
        public IActionResult Consulter(int id)
        {
            var personneRecherché = _baseDonnees.Personnes.FirstOrDefault(p => p.Id == id);
            if (personneRecherché == null)
            {
                return NotFound();
            }
            else
            {
                return View(personneRecherché);
            }
        }

    }
}