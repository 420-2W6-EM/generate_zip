﻿using Microsoft.AspNetCore.Mvc;

namespace Exemple.Controllers
{
    public class RoutageExemple1Controller : Controller
    {

        [Route("client")]
        [Route("client/Index")]
        public IActionResult Index()
        {
            return Content("Exemple 1 - Index");
        }

        [Route("client/{cientId:int}")]
        public IActionResult ObtenirClientParId(int clientId)
        {
            return Content("Exemple 2 - ObtenirClientParId");
        }

        [Route("client/{clientName}")]
        public IActionResult ObtenirClientParNom(string clientName)
        {
            return Content("Exemple 3 - ObtenirClientParNom");
        }

        [Route("client/{clientName}/edit")]
        [Route("client/edit/{clientName}")]
        public IActionResult Edit(int clientId)
        {
            return Content("Exemple 4 - Edit");
        }

    }
}