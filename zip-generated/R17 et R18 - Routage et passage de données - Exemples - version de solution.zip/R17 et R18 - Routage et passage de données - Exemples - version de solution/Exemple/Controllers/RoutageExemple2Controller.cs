﻿using Microsoft.AspNetCore.Mvc;

namespace Exemple.Controllers
{
    [Route("Animal")]
    public class RoutageExemple2Controller : Controller
    {

        [Route("")]
        [Route("Index")]
        public IActionResult Index()
        {
            return Content("Exemple 5 - Index");
        }

        [Route("{animalId}")]
        public IActionResult Details(int animalId)
        {
            return Content("Exemple 6 - Details");
        }

        [Route("{clientId}/Edit")]   //GET: Animal/1/Edit
        public IActionResult Edit(int clientId)
        {
            return Content("Exemple 7 - Edit");
        }

    }
}