﻿using Exemple.Models;
using Exemple.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Exemple.Controllers
{
    public class PassageDonnees : Controller
    {

        BaseDonnees _baseDonnees;
        public PassageDonnees(BaseDonnees donnees)
        {
            _baseDonnees = donnees;
        }

        [Route("/")]
        [Route("passagedonnees")]
        public IActionResult Menu()
        {
            return View();
        }

        [Route("passagedonnees/consulter/{personneId:int}")]
        public IActionResult Consulter(int personneId)
        {
            PersonneModel unePersonne = _baseDonnees.Personnes.Where(element => element.Id == personneId).Single();
            return View("Afficher", unePersonne);
        }

        [Route("passagedonnees/exemple1/{personneId:int}")]
        public IActionResult Edit1(int personneId)
        {
            /* Version avec un modèle et le ViewData*/
            PersonneModel unePersonne = _baseDonnees.Personnes.Where(p => p.Id == personneId).Single();
            ViewData["nomUtilisateur"] = "Francois Jasmin"; //var nom = ViewData["nomUtilisateur"]
            ViewData["forfaits"] = _baseDonnees.Forfaits.ToList(); //var forfaits = ViewData["forfaits"] as List<ForfaitModel>
            return View(unePersonne);
        }

        [Route("passagedonnees/exemple2/{personneId:int}")]
        public IActionResult Edit2(int personneId)
        {
            /* Version avec un modèle et le ViewBag*/
            PersonneModel unePersonne = _baseDonnees.Personnes.Where(p => p.Id == personneId).Single();
            ViewBag.nomUtilisateur = "Francois Jasmin"; //var nom = ViewData.nomUtilisateur
            ViewBag.forfaits = _baseDonnees.Forfaits.ToList(); //var forfaits = ViewBag.forfaits
            return View(unePersonne);

        }

        [Route("passagedonnees/exemple3/{personneId:int}")]
        public IActionResult Edit3(int personneId)
        {
            /* Version avec un modèle de vue*/
            var donnees = new AffichageExempleViewModel();
            donnees.NomUtilisateur = "Francois Jasmin";
            donnees.Forfaits = _baseDonnees.Forfaits.ToList();
            donnees.UnePersonne = _baseDonnees.Personnes.Where(p => p.Id == personneId).Single();
            return View(donnees);
        }

        [HttpPost]
        [Route("passagedonnees/enregistrer")]
        public IActionResult Enregistrer([FromForm] PersonneModel infoPersonneModifiée)
        {
            //Enregistrement des changements dans la BD
            var personneDansLaBD = _baseDonnees.Personnes.Where(p => p.Id == infoPersonneModifiée.Id).First();
            personneDansLaBD.Nom = infoPersonneModifiée.Nom;
            personneDansLaBD.ForfaitId = infoPersonneModifiée.ForfaitId;
            personneDansLaBD.Forfait = _baseDonnees.Forfaits.Where(f => f.Id == infoPersonneModifiée.ForfaitId).Single();
            personneDansLaBD.Age = infoPersonneModifiée.Age;
            return View("Afficher", personneDansLaBD);
        }
    }
}