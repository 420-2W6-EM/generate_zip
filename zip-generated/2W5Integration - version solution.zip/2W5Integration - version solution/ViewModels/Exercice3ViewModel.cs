﻿using _2W5Integration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.ViewModels
{
    public class Exercice3ViewModel
    {
        public Recette Recette { get; set; }
    }
}
