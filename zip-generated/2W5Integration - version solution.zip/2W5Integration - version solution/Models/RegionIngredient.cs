﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class RegionIngredient
    {
        public int IdRegion { get; set; } //PK et FK
        public int IdIngredient { get; set; } //PK et FK

        public Region Region { get; set; }
        public Ingredient Ingredient { get; set; }
    }
}
