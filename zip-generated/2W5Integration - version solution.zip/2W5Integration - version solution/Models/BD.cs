﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class BD
    {
        public List<CreatureDivine> CreatureDivines { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Prodige> Prodiges { get; set; }
        public List<Recette> Recettes { get; set; }
        public List<Region> Regions { get; set; }
        public List<RegionIngredient> RegionIngredients { get; set; }
        public List<Sanctuaire> Sanctuaires { get; set; }
        public List<IngredientRecette> IngredientRecettes { get; set; }
    }
}
