﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class Ingredient
    {
        public int Id { get; set; } //PK
        public string Nom { get; set; }
        public string Description { get; set; }

        public List<RegionIngredient> RegionIngredients { get; set; }
        public List<IngredientRecette> IngredientRecettes { get; set; }
    }
}
