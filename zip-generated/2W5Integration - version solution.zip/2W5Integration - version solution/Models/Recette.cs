﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class Recette
    {
        public int Id { get; set; } //PK

        public string Nom { get; set; }
        public string Description { get; set; }
        public int? DuréeEffetEnSeconde { get; set; }
        public int? NombreCoeurRestauré { get; set; }
        public int? NombreEnduranceAjouté { get; set; }
        public int? NiveauDefenseAugmenté { get; set; }
        public int? NiveauAttaqueAugmenté { get; set; }
        public int? NiveauVitesseAugmenté { get; set; }

        public List<IngredientRecette> IngredientRecettes { get; set; }
    }
}
