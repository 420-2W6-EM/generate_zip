﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class Prodige
    {
        public int Id { get; set; } //PK
        public string Nom { get; set; }
        public string Image { get; set; }

        public int IdCreatureDivine { get; set; } //FK
        public CreatureDivine CreatureDivine { get; set; }
    }
}
