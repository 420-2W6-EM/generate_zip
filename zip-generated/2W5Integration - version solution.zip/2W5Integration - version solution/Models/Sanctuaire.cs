﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class Sanctuaire
    {
        public int Id { get; set; } //PK
        public string Nom { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }

        public int IdRegion { get; set; } //FK
        public Region Region { get; set; }
    }
}
