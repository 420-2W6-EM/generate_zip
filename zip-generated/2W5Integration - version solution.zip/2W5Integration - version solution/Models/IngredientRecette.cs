﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Models
{
    public class IngredientRecette
    {
        public int IdRecette { get; set; } //PK et FK
        public int IdIngredient { get; set; } //PK et FK

        public Recette Recette { get; set; }
        public Ingredient Ingredient { get; set; }

        public int Quantité { get; set; }
    }
}
