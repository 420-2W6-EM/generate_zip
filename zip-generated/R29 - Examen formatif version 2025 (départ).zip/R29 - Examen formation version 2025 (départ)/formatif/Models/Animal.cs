﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace formatif.Models
{
    public class Animal
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public double Poids { get; set; }
        public string Nourriture { get; set; }
    }
}
