﻿using AmongUs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmongUs.Controllers
{
    public class CrewmateController : Controller
    {
        private Database DB;
        public CrewmateController(Database db)
        {
            DB = db;
        }
        // GET: CrewmateController
        public ActionResult Index()
        {
            ViewData["fav"] = HttpContext.Session.GetString("fav");
            return View(DB.Crewmates.ToList());
        }

        public ActionResult Buy()
        {
            return View(DB.Cosmetics.ToList());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Buy(int Id)
        {
            List<Cosmetic> cosmetics = HttpContext.Session.Get<List<Cosmetic>>("cart");

            if (cosmetics == null)
            {
                cosmetics = new List<Cosmetic>();
            }

            cosmetics.Add(DB.Cosmetics.Where(d => d.Id == Id).Single());
            HttpContext.Session.Set<List<Cosmetic>>("cart", cosmetics);

            Cosmetic rare = DB.Cosmetics.Where(d => d.Id == Id).Single();
            rare.Price += 1.0;
            return RedirectToAction("Cart");
        }

        public ActionResult Cart()
        {
            List<Cosmetic> cosmetics = HttpContext.Session.Get<List<Cosmetic>>("cart");
            return View(cosmetics);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Favorite(string color)
        {
            HttpContext.Session.SetString("fav", color);
            return RedirectToAction("Index");
        }
    }
}
