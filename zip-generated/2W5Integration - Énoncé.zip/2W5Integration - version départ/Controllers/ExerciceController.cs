﻿using _2W5Integration.Models;
using _2W5Integration.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2W5Integration.Controllers
{
    public class ExerciceController : Controller
    {

        public BD Database { get; set; }

        public ExerciceController(BD pDataBase)
        {
            Database = pDataBase;
        }

        public IActionResult Exercice1()
        {
            return View();
        }

        public IActionResult Exercice2(int idIngredient)
        {
            return View();
        }

        public IActionResult Exercice3(int idRecette)
        {
            return View();
        }

        public IActionResult Exercice4()
        {
            return View();
        }

        public IActionResult Exercice5()
        {
            return View();
        }

        public IActionResult Exercice6(int idRegion)
        {
            return View();
        }

        public IActionResult Exercice7(int? idRegion)
        {
            return View();
        }

        public IActionResult Exercice8(int idIngredient)
        {
            return View();
        }
    }
}
