﻿namespace ExercicePokemon.ViewModels
{
    public class Info18ViewModel
    {
        public double MoyenneFeu { get; set; }
        public double MoyenneEau { get; set; }
        public double MoyenneHerbe { get; set; }
    }
}
