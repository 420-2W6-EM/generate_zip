﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiseANiveau.Models
{
    public class Combat
    {
        public Pokemon Pokemon1 { get; set; }
        public Pokemon Pokemon2 { get; set; }
        public bool Pokemon2Gagant { get; set; }
    }
}
