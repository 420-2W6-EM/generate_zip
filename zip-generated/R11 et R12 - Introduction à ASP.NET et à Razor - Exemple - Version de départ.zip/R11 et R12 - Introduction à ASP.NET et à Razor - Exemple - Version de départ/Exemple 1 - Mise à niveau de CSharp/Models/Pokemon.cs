﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiseANiveau.Models
{
    public class Pokemon
    {
        public string Nom { get; set; }
        public int Level { get; set; }
    }
}
