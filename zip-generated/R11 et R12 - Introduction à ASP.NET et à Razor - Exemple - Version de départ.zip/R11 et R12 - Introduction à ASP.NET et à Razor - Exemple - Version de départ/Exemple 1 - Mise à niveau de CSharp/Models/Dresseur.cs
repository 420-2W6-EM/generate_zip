﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiseANiveau.Models
{
    public class Dresseur
    {
        public string Nom { get; set; }
        public List<Pokemon> Pokemons { get; set; }
    }
}
