﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiseANiveau.Controllers
{
    class CombatController
    {
        public void Action1()
        {

        }
        public void Action2()
        {

        }
    }
}
