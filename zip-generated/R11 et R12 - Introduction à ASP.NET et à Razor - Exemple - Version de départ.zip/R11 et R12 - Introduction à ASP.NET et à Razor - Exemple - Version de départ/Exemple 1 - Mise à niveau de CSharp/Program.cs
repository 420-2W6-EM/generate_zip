﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiseANiveau
{
    class Program
    {
        static void Main(String[] args)
        {
            Principale app = new Principale();
            app.InferenceDeType();
            app.SiTernaire();
            app.TypeDéfini();
            app.TypeAnonyme();
            app.BibliothequeExterne();
        }
    }
}
