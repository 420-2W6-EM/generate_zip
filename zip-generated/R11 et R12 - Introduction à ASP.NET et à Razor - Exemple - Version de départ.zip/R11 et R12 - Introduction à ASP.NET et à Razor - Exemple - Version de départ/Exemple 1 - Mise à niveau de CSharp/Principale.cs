﻿using MiseANiveau.Models;
using MiseANiveau.Controllers;
using System;
using System.Collections.Generic;

namespace MiseANiveau
{
    public class Principale
    {

        public void InferenceDeType()
        {
            int code1 = 404;
            string code2 = "200";
            Pokemon pokemon = new Pokemon() { Nom = "Pikachu", Level = 50 };

            Console.WriteLine(code1);
            Console.WriteLine(code2);
            Console.WriteLine(pokemon.Nom);
        }

        public void SiTernaire()
        {
            var age = 23;
            string message = "";
            
            if (age >= 18)
            {
                message = "Vous êtes majeur";
            } else
            {
                message = "Vous êtes mineur";
            }

            //message = age >= 18 ? "Vous êtes majeur" : "Vous êtes mineur";

            Console.WriteLine(message);
        }

        public void TypeDéfini()
        {
            var typeDéfini = new Pokemon() { Nom = "Pikachu", Level = 50 };
            Console.WriteLine(typeDéfini.Nom);

            var listeTypeDéfini = new Pokemon[]
            {
                    new Pokemon(){ Nom = "Bulbizarre", Level = 50 },
                    new Pokemon(){ Nom = "Carapuce", Level = 12 },
                    new Pokemon(){ Nom = "Onix", Level = 34 },
            };

            foreach (Pokemon element in listeTypeDéfini)
            {
                Console.WriteLine(element.Nom + " " + element.Level.ToString());
            }
        }

        public void TypeAnonyme()
        {
            var typeAnonyme = new { Propriété1 = "A", Propriété2 = 2 };
            Console.WriteLine(typeAnonyme.Propriété1);

            var listeTypeAnonyme = new[]
            {
                    new { Propriété1 = "A", Propriété2 = 1 },
                    new { Propriété1 = "B", Propriété2 = 2 },
                    new { Propriété1 = "C", Propriété2 = 3 }
            };

            foreach (var element in listeTypeAnonyme)
            {
                Console.WriteLine(element.Propriété1 + " " + element.Propriété2.ToString());
            }
        }

        public void AmbiguitéImportationDesNamespaces()
        {
            //var instance = new ClasseA();
        }

        public void BibliothequeExterne()
        {
            /*
            var uneAdresseCourrielFake = Faker.Internet.Email();
            Console.WriteLine(uneAdresseCourrielFake);
            */
        }
    }
}