﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmongUs.Models
{
    public class Database
    {
        public List<Crewmate> Crewmates { get; set; }
        public List<Cosmetic> Cosmetics { get; set; }
        public Database()
        {
            Crewmates = new List<Crewmate>(); // Création d'une liste vide
            Cosmetics = new List<Cosmetic>(); // Création d'une liste vide

            // Création de 6 Crewmates
            Crewmates.Add(new Crewmate()
            {
                Color = "Rouge",
                IsImposter = true,
                Victories = 2,
                FavoriteMap = "The Skeld",
                Strategy = "Tuer le plus rapidement possible les Crewmates car ils vont trouver Rouge sus dans tous les cas."
            });
            Crewmates.Add(new Crewmate()
            {
                Color = "Bleu",
                IsImposter = false,
                Victories = 0,
                FavoriteMap = "Mira HQ",
                Strategy = "Crier « Rouge sus ! » sans arrêt dès la première rencontre."
            });
            Crewmates.Add(new Crewmate()
            {
                Color = "Vert",
                IsImposter = false,
                Victories = 1,
                FavoriteMap = "Polus",
                Strategy = "Afk au début de la partie car sa maman l'appelle pour le dîner. Rip."
            });
            Crewmates.Add(new Crewmate()
            {
                Color = "Orange",
                IsImposter = false,
                Victories = 0,
                FavoriteMap = "The Skeld",
                Strategy = "Faire un Emergency Call pour dire qu'il doit aller aux toilettes."
            });
            Crewmates.Add(new Crewmate()
            {
                Color = "Rose",
                IsImposter = true,
                Victories = 1,
                FavoriteMap = "Polus",
                Strategy = "Agencer élégamment ses cosmétiques pour perdre avec style."
            });
            Crewmates.Add(new Crewmate()
            {
                Color = "Jaune",
                IsImposter = false,
                Victories = 2,
                FavoriteMap = "Mira HQ",
                Strategy = "Aller aux caméras sans jamais accomplir ses tâches. Bravo champion."
            });

            Cosmetics.Add(new Cosmetic()
            { Id = 1, Name = "Dog", Price = 5.5, ImgUrl = "dog" }
                );
            Cosmetics.Add(new Cosmetic()
            { Id = 2, Name = "Baby", Price = 10.0, ImgUrl = "baby" }
                );
            Cosmetics.Add(new Cosmetic()
            { Id = 3, Name = "Bedcrab", Price = 2.5, ImgUrl = "bedcrab" }
                );
            Cosmetics.Add(new Cosmetic()
            { Id = 4, Name = "Slug", Price = 1.75, ImgUrl = "slug" }
                );
            Cosmetics.Add(new Cosmetic()
            { Id = 5, Name = "UFO", Price = 40.0, ImgUrl = "ufo" }
                );
            Cosmetics.Add(new Cosmetic()
            { Id = 6, Name = "Hamster", Price = 8.0, ImgUrl = "hamster" }
                );
        }
    }
}
