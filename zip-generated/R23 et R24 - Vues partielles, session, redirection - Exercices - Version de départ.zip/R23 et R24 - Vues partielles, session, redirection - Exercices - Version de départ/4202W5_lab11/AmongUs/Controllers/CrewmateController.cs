﻿using AmongUs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmongUs.Controllers
{
    public class CrewmateController : Controller
    {
        private Database DB;
        public CrewmateController(Database db)
        {
            DB = db;
        }
        // GET: CrewmateController
        public ActionResult Index()
        {
            // Récupérer la variable de session avec la clé "fav" et la glisser dans ViewData["fav"]
            return View(DB.Crewmates.ToList());
        }

        public ActionResult Buy()
        {
            return View(DB.Cosmetics.ToList());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Buy(int Id)
        {
            // Trouver la cosmétique avec cet Id dans la base de données
            // Récupérer le panier de l'utilisateur dans les variables de session
            // Ajouter la cosmétique à la liste des cosmétiques dans le panier de l'utilisateur
            // Mettre à jour le panier dans les variables de session
            // remplacer le Return View() par une redirection vers le panier
            return View(DB.Cosmetics.ToList());
        }

        public ActionResult Cart()
        {
            List<Cosmetic> cosmetics = new List<Cosmetic>(); // Aller chercher cette liste dans les variables de session à la place
            return View(cosmetics);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Favorite(string Color)
        {
            // Insérer le string reçu dans les variables de session avec la clé "fav"
            return View("Index");
        }
    }
}
