import { createRouter, createWebHistory } from 'vue-router'
import PokemonDetailView from '../views/PokemonDetailView.vue'
import PokemonListView from '../views/PokemonListView.vue'
import TrainerDetailView from '../views/TrainerDetailView.vue'
import TrainerListView from '../views/TrainerListView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/pokemons',
      name: 'home',
      component: PokemonListView,
    },
    {
      path: '/pokemons/detail/:id',
      name: 'pokemonsdetail',
      component: PokemonDetailView,
    },
    {
      path: '/dresseurs',
      name: 'dresseurslist',
      component: TrainerListView,
    },
    {
      path: '/dresseurs/detail/:id',
      name: 'dresseurdetail',
      component: TrainerDetailView,
    }
  ],
})

export default router
