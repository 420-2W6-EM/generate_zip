<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
    <header class="container-fluid">
      <div class="row">
        <div class="col text-center">
          <img src="@/assets/logo.png" alt="Logo" class="logo" />
              <div class="col text-center">
                  <RouterLink class="optionMenu" to="/pokemons">Liste des pokémons</RouterLink>
                  <RouterLink class="optionMenu" to="/dresseurs">Liste des dresseurs</RouterLink>
              </div>
          </div>
        </div>
    </header>
    <main class="container">
      <div class="row">
          <div class="col pt-3" id="ContenuDuRenderBody">
              <RouterView />
          </div>
      </div>
    </main>
</template>

<style scoped>
  .optionMenu {
    display: inline-block;
    margin: 1em;
    padding: 0.5em;
    border: solid white 1px;
    cursor: pointer;
    background-color: rgba(255,255,255,0.25);
  }
</style>
