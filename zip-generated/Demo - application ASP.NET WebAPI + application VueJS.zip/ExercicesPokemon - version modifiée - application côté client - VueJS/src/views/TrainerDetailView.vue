<template>
  <div v-if="dresseur">
    <h1>Dresseur : {{ dresseur?.nom }}</h1>
    <hr />
    <div class="row">
      <div class="col-sm-12">
        <img :src="`data:image/jpg;base64,${dresseur?.image}`" style="max-width:200px;" class="mb-3" />
      </div>
      <div class="col-sm-2">
        Arèna
      </div>
      <div class="col-sm-10">
        {{ dresseur?.arena }}
      </div>
      <div class="col-sm-2">
        Spécialité
      </div>
      <div class="col-sm-10">
        {{ dresseur?.typeSpecialisé }}
      </div>
    </div>

    <h3 class="mt-5">Liste de ses pokémons</h3>
    <br />
    <br />
    <div class="row">
      <div v-for="pokemonDresseur in dresseur?.pokemonsDresseur" :key="pokemonDresseur.pokemon.id" class="pokemon" style="margin: 10px; display: inline-block; text-align: center;">
        <router-link :to="`/pokemons/detail/${pokemonDresseur.pokemon.id}`">
          <img :src="`data:image/png;base64,${pokemonDresseur.pokemon.image}`" alt="Image du pokémon" style="max-width:100px;" /><br />
          {{ pokemonDresseur.pokemon.nom }} <br />
          Niveau {{ pokemonDresseur.niveau }}
        </router-link>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-12 mt-5">
        <router-link to="/dresseurs" class="btn btn-primary">Retour à la liste</router-link>
      </div>
    </div>
  </div>
  <div v-else>
    <p>Chargement des données...</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';

// Propriété réactive pour stocker les détails du dresseur
const dresseur = ref(null);

// Récupérer l'ID du dresseur depuis les paramètres de la route
const route = useRoute();
const dresseurId = route.params.id;

// Fonction pour récupérer les données du dresseur depuis l'API
const fetchDresseurDetails = async () => {
  try {
    const response = await fetch(`http://localhost:44909/api/dresseur/consulter/${dresseurId}`);
    if (!response.ok) {
      throw new Error('Erreur lors de la récupération des détails du dresseur');
    }
    const data = await response.json();
    dresseur.value = data; // Stocker les données dans la propriété réactive
    console.log(data); // Afficher les données dans la console
  } catch (error) {
    console.error(error);
  }
};

// Appeler l'API lors du montage du composant
onMounted(() => {
  fetchDresseurDetails();
});
</script>

<style>

</style>