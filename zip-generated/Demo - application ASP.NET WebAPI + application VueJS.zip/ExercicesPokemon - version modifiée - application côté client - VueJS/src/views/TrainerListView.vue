<template>
  <div>
    <h1>Liste des Dresseurs</h1>
    <div v-if="dresseurs" class="mt-5">
      <table class="table table-light">
        <thead class="thead-light">
          <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Image</th>
            <th>Arèna</th>
            <th>Type spécialisé</th>
            <th>Nombre de pokémons</th>
            <th>Att. moyenne des pokémons</th>
            <th>Déf. moyenne des pokémons</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="dresseur in dresseurs" :key="dresseur.id">
            <td>{{ dresseur.id }}</td>
            <td>{{ dresseur.nom }}</td>
            <td>
              <img :src="`data:image/jpg;base64,${dresseur.image}`" alt="Image du dresseur" style="max-width:100px;" />
            </td>
            <td>{{ dresseur.arena }}</td>
            <td>{{ dresseur.typeSpecialisé }}</td>
            <td>{{ dresseur.pokemonsDresseur?.length ?? 0 }}</td>
            <td>
              {{
                dresseur.pokemonsDresseur && dresseur.pokemonsDresseur.length > 0
                  ? (
                      dresseur.pokemonsDresseur.reduce((sum, pd) => sum + (pd.pokemon?.attaque ?? 0), 0) /
                      dresseur.pokemonsDresseur.length
                    ).toFixed(2)
                  : '-'
              }}
            </td>
            <td>
              {{
                dresseur.pokemonsDresseur && dresseur.pokemonsDresseur.length > 0
                  ? (
                      dresseur.pokemonsDresseur.reduce((sum, pd) => sum + (pd.pokemon?.defense ?? 0), 0) /
                      dresseur.pokemonsDresseur.length
                    ).toFixed(2)
                  : '-'
              }}
            </td>
            <td>
              <router-link :to="`/dresseurs/detail/${dresseur.id}`" class="btn btn-primary">
                Consulter
              </router-link>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  
    <div v-else>
      <p>Chargement des données...</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

// Propriété réactive pour stocker la liste des dresseurs
const dresseurs = ref([]);

// Fonction pour récupérer les données depuis l'API
const fetchDresseurs = async () => {
  try {
    const response = await fetch('http://localhost:44909/api/dresseur/lister');
    if (!response.ok) {
      throw new Error('Erreur lors de la récupération des dresseurs');
    }
    const data = await response.json();
    dresseurs.value = data; // Stocker les données dans la propriété réactive
  } catch (error) {
    console.error(error);
  }
};

// Appeler l'API lors du montage du composant
onMounted(() => {
  fetchDresseurs();
});
</script>