<template>
<div v-if="notFound" class="text-center mt-5">
    <h1>pokémon non-trouvé</h1>
    <img src="@/assets/confusionpsyduck.jpg" alt="Pokémon non trouvé" style="max-width:300px;" />
</div>
<div v-else>
  <div class="row" v-if="pokemon">
      <div class="col">
          <h1 class="text-uppercase">{{ pokemon.nom }}</h1>
          <img :src="`data:image/png;base64,${pokemon.image}`" alt="Image de {{ pokemon.nom }}" style="max-width: 200px;"/><br /><br />
          Id : {{ pokemon.id }}  <br />
          Nom : {{ pokemon.nom }} <br />
          Type : {{ pokemon.typePrimaire }}<span v-if="pokemon.typeSecondaire">, {{ pokemon.typeSecondaire }}</span>
          <span v-if="pokemon.legendaire">
            <br />
            <span>EST UN POKÉMON LÉGENDAIRE</span>
          </span>
          <br />
          <br />
          {{ pokemon.description }}
      </div>
      <div class="col">
          <h2 class="text-uppercase">Statistiques</h2>
          HP : {{ pokemon.hp }} <br />
          Vitesse : {{ pokemon.vitesse }} <br />
          Total : {{ pokemon.total }}  <br />
          <h2 class="my-5 text-uppercase">Attaque/Défence</h2>
          <table id="tableauStatistique" class="table">
              <thead>
                  <tr>
                      <th class="transparent"></th>
                      <th class="couleurDark">Attaque</th>
                      <th class="couleurDark">Défence</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td class="couleurDark">De base</td>
                      <td>{{ pokemon.attaque }}</td>
                      <td>{{ pokemon.defense }}</td>
                  </tr>
                  <tr>
                      <td class="couleurDark">Spécial</td>
                      <td>{{ pokemon.specialAttaque }}</td>
                      <td>{{ pokemon.specialDefense }}</td>
                  </tr>
              </tbody>
          </table>
      </div>
    </div>
    <div v-else>
      <p>Chargement des données...</p>
    </div>
    <div class="row mt-5">
        <div class="col text-center">
            <a href="/pokemons/" class="btn btn-primary">Retour</a>
        </div>
    </div>
</div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';

// Propriété réactive pour stocker les détails du Pokémon
const pokemon = ref(null);
// Propriété réactive pour l'état 404
const notFound = ref(false);

// Récupérer l'ID du Pokémon depuis les paramètres de la route
const route = useRoute();
const pokemonId = route.params.id;

// Fonction pour récupérer les données du Pokémon depuis l'API
const fetchPokemonDetails = async () => {
  try {
    const response = await fetch(`http://localhost:44909/api/pokemon/consulter/${pokemonId}`);
    if (response.status === 404) {
      notFound.value = true;
      return;
    }
    if (!response.ok) {
      throw new Error('Erreur lors de la récupération des détails du Pokémon');
    }
    const data = await response.json();
    pokemon.value = data; // Stocker les données dans la propriété réactive
  } catch (error) {
    console.error(error);
  }
};

// Appeler l'API lors du montage du composant
onMounted(() => {
  fetchPokemonDetails();
});
</script>