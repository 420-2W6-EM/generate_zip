<template>
  <div>
    <h1>Liste des pokémons</h1>
    <div v-if="pokemons" class="mt-5">
      <span v-for="pokemon in pokemons" :key="pokemon.id">
        <router-link :class="['pokemon', { legendaire: pokemon.legendaire }]" :to="`/pokemons/detail/${pokemon.id}`">
          {{ pokemon.nom }}
          <br>
          <img :src="`data:image/png;base64,${pokemon.image}`" alt="Image de {{ pokemon.nom }}" style="max-width: 120px;"/>
        </router-link>
      </span>
    </div>
    <div v-else>
      <p>Chargement des données...</p>
    </div>
  </div>
</template>


<script setup>
import { ref, onMounted } from 'vue';

// Propriété réactive pour stocker la liste des pokémons
const pokemons = ref([]);

// Fonction pour récupérer les données depuis l'API
const fetchPokemons = async () => {
  try {
    const response = await fetch('http://localhost:44909/api/pokemon/lister');
    if (!response.ok) {
      throw new Error('Erreur lors de la récupération des pokémons');
    }
    const data = await response.json();
    console.log(data); // Afficher les données dans la console
    pokemons.value = data; // Stocker les données dans la propriété réactive
  } catch (error) {
    console.error(error);
  }
};

// Appeler l'API lors du montage du composant
onMounted(() => {
  fetchPokemons();
});
</script>

<style>

.pokemon {
  width: 150px;
  height: 150px;
  padding: 1px;
  cursor: pointer;
  display: inline-block;
  text-align: center;
  border: 1px solid transparent;
}

.pokemon:hover {
  background-color: rgba(30, 144, 255, 0.5);
  border: 1px solid rgb(30, 144, 255);
}

.legendaire {
  border: 1px solid rgba(168, 50, 84, 1);
  background-color: rgba(168, 50, 84, 0.5);
}

</style>
