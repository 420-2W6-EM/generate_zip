using Microsoft.AspNetCore.Mvc;
using ExercicePokemon.Models;
using Microsoft.EntityFrameworkCore;

namespace ExercicesPokemon.ApiControllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DresseurController : ControllerBase
    {
        private readonly BaseDeDonnees _baseDeDonnees;

        public DresseurController(BaseDeDonnees baseDeDonnees)
        {
            _baseDeDonnees = baseDeDonnees;
        }

        [HttpGet("Lister")]
        public IActionResult Lister()
        {
            var pokemons = _baseDeDonnees.Dresseurs.Include(d => d.PokemonsDresseur)
                                                   .ThenInclude(pd => pd.Pokemon)
                                                   .Select(d => new
                                                    {
                                                        d.Id,
                                                        d.Nom,
                                                        d.Arena,
                                                        d.PokemonsDresseur,
                                                        d.TypeSpecialisé,
                                                        Image = Convert.ToBase64String(d.Image),
                                                    })
                                                   .ToList();
            return Ok(pokemons); // Retourne les données en JSON, avec code 200 (OK)
        }

        [HttpGet("Consulter/{id}")]
        public IActionResult Consulter(int id)
        {
            var dresseurRecherché = _baseDeDonnees.Dresseurs.Include(d => d.PokemonsDresseur)
                                                            .ThenInclude(pd => pd.Pokemon)
                                                            .Where(d => d.Id == id)
                                                            .Select(d => new
                                                            {
                                                                d.Id,
                                                                d.Nom,
                                                                d.Arena,
                                                                d.PokemonsDresseur,
                                                                d.TypeSpecialisé,
                                                                Image = Convert.ToBase64String(d.Image),
                                                            })
                                                            .SingleOrDefault();
            if (dresseurRecherché == null)
            {
                return NotFound("Le numéro de dresseur n'a pas été trouvé!"); // Retourne un 404 (NotFound)
            }
            else
            {
                return Ok(dresseurRecherché); // Retourne les données en JSON, avec code 200 (OK)
            }
        }
    }
}