using Microsoft.AspNetCore.Mvc;
using ExercicePokemon.Models;

namespace ExercicesPokemon.ApiControllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PokemonController : ControllerBase
    {
        private readonly BaseDeDonnees _baseDeDonnees;

        public PokemonController(BaseDeDonnees baseDeDonnees)
        {
            _baseDeDonnees = baseDeDonnees;
        }

        [HttpGet("Lister")]
        public IActionResult Lister()
        {
            var pokemons = _baseDeDonnees.Pokemons.Select(p =>
                 new
                 {
                     p.Id,
                     p.Nom,
                     p.TypePrimaire,
                     p.TypeSecondaire,
                     p.Total,
                     p.HP,
                     p.Defense,
                     p.Attaque,
                     p.SpecialAttaque,
                     p.SpecialDefense,
                     p.Vitesse,
                     p.Generation,
                     p.Legendaire,
                     p.Description,
                     Image = Convert.ToBase64String(p.Image)
                 }
            ).ToList();
            return Ok(pokemons); // Retourne les données en JSON
        }

         [HttpGet("Consulter/{id}")]
        public IActionResult Consulter(int id)
        {
            var pokemonRecherché = _baseDeDonnees.Pokemons.Where(p => p.Id == id)
                                                          .Select(p => new
                                                              {
                                                                    p.Id,
                                                                    p.Nom,
                                                                    p.TypePrimaire,
                                                                    p.TypeSecondaire,
                                                                    p.Total,
                                                                    p.HP,
                                                                    p.Defense,
                                                                    p.Attaque,
                                                                    p.SpecialAttaque,
                                                                    p.SpecialDefense,
                                                                    p.Vitesse,
                                                                    p.Generation,
                                                                    p.Legendaire,
                                                                    p.Description,
                                                                    Image = Convert.ToBase64String(p.Image)
                                                              }
                                                           ).SingleOrDefault();
            if (pokemonRecherché == null)
            {
                return NotFound("Le numéro de pokémon n'a pas été trouvé!");
            }
            else
            {
                return Ok(pokemonRecherché);
            }
        }
    }
}