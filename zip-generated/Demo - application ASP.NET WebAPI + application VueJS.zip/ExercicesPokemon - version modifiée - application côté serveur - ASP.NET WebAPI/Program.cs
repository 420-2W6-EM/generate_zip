using ExercicePokemon.Models;
using Microsoft.EntityFrameworkCore;


var builder = WebApplication.CreateBuilder(args); // Crée une web app avec les param�tres envoy�s

// Ajouter les services CORS (permettre à l'API d'être accessible depuis d'autres origines)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

// Permet de gérer les références circulaires dans les objets (nécessaire pour du JSON)
builder.Services.AddControllersWithViews() // Permet MVC
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
                });

// Ajouter le service DbContext (EfCore) pour la base de données
builder.Services.AddDbContext<BaseDeDonnees>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")).EnableSensitiveDataLogging(true)
); 


var app = builder.Build();

// Appliquer la politique CORS
app.UseCors("AllowAll");

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseRouting();
app.UseEndpoints(endpoints =>
{
    _ = endpoints.MapControllerRoute( name: "default", pattern: "{controller}/{action}/{id?}");
});

app.Run();