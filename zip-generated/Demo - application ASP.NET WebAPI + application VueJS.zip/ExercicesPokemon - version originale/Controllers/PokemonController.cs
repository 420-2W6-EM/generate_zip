﻿using ExercicePokemon.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace ExercicePokemon.Controllers
{
    public class PokemonController : Controller
    {
        private BaseDeDonnees _baseDeDonnees { get; set; }

        public PokemonController(BaseDeDonnees baseDeDonnees)
        {
            _baseDeDonnees = baseDeDonnees;
        }

        public IActionResult Lister()
        {
            return View(_baseDeDonnees.Pokemons.ToList());
        }

        public IActionResult Consulter(int id)
        {
            var pokemonRecherché = _baseDeDonnees.Pokemons.Where(p => p.Id == id).SingleOrDefault();
            if (pokemonRecherché == null)
            {
                return View("NonTrouvé", "Le numéro de pokémon demandé n'a pas été trouvé!");
            }
            else
            {
                return View(pokemonRecherché);
            }
        }
    }
}