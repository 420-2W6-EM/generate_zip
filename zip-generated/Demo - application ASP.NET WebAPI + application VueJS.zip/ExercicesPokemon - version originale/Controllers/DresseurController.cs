﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ExercicePokemon.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExercicePokemon.Controllers
{
    public class DresseurController : Controller
    {

        private BaseDeDonnees _baseDeDonnees { get; set; }

        public DresseurController(BaseDeDonnees baseDeDonnees)
        {
            _baseDeDonnees = baseDeDonnees;
        }

        public IActionResult Lister()
        {
            return View(_baseDeDonnees.Dresseurs.ToList());
        }

        public IActionResult Consulter(int id)
        {
            var dresseurRecherché = _baseDeDonnees.Dresseurs.Where(d => d.Id == id).SingleOrDefault();
            if (dresseurRecherché == null)
            {
                return View("NonTrouvé", "Le numéro de dresseur n'a pas été trouvé!");
            }
            else
            {
                return View(dresseurRecherché);
            }
        }
    }
}