﻿namespace Exemple.Models
{
    public class FausseBaseDonnees
    {
        public List<Personne> ObtenirListePersonnes()
        {
            var personnes = new List<Personne>() {
                new Personne() { Id=1, Nom = "Robert Lapointe", Nas = "276-187-261", Age = 17, Image="/images/personne1.jpg", AÉtéFraudé = false },
                new Personne() { Id=2, Nom = "Denis Verreau", Nas = "527-189-354", Age = 20, Image="/images/personne2.jpg", AÉtéFraudé = true  },
                new Personne() { Id=3, Nom = "Louise Tremblay", Nas = "782-356-273", Age = 28, Image="/images/personne3.jpg", AÉtéFraudé = false }
            };
            return personnes;
        }
    }
}
