﻿using Exemple.Models;
using Microsoft.AspNetCore.Mvc;

namespace Exemple.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //return View();
            return Content("Action 1 Index");
        }
        public IActionResult Action2()
        {
            //return View();
            var donnees = ObtenirListePersonnes();
            return View(donnees);

        }
        public IActionResult Action3()
        {
            //return View();
            return View();
        }

        private List<Personne> ObtenirListePersonnes()
        {
            var personnes = new List<Personne>() {
                new Personne() { Id=1, Nom = "Robert Lapointe", Nas = "276-187-261", Age = 17, Image="/images/personne1.jpg", AÉtéFraudé = false },
                new Personne() { Id=2, Nom = "Denis Verreau", Nas = "527-189-354", Age = 20, Image="/images/personne2.jpg", AÉtéFraudé = true  },
                new Personne() { Id=3, Nom = "Louise Tremblay", Nas = "782-356-273", Age = 28, Image="/images/personne3.jpg", AÉtéFraudé = false }
            };
            return personnes;
        }
    }
}
